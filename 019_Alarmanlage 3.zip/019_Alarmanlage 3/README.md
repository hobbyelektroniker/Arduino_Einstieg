# Der einfache Einstieg in Arduino & Co. 19: Alarmanlage 3 - Mit LED - Ausgabe
 
https://youtu.be/z3chfEy1ITQ

Jetzt programmieren wir noch die Ausgabe mit den LEDs. Hier wird ausgiebig von Arrays und millis() Gebrauch gemacht. Selbstverständlich wird das als Modul realisiert. Bei dieser Gelegenheit wird auch die Displayausgabe in ein Modul verpackt. Die Alarmanlage ist dann betriebsbereit.
Lade unbedingt das Begleitmaterial herunter. Du findest dort unter Anderem eine Kurzanleitung zum Erstellen von Modulen. 

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/24

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



