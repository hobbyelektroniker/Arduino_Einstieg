# Der einfache Einstieg in Arduino & Co. 26 - Von der Idee zum Projekt 
 
https://youtu.be/BXyUDU7lYYs

Du möchtest ein Projekt realisieren, aber schon nach kurzer Zeit verlierst du die Übersicht. Vielleicht ist es dir auch schon so ergangen. An einem einfachen Beispiel realisieren wir in diesem Video ein Projekt, ohne die Kontrolle zu verlieren.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/67

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



