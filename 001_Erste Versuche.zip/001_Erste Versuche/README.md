# Der schnelle Einstieg in Arduino & Co. 1: Erste Versuche
 
https://youtu.be/CkObbLxJMI4

Wir haben das Material erhalten und bereiten alles vor. Mindestens eine LED sollten wir doch zum Blinken bringen.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/24

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



