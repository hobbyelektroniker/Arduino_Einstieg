# Der einfache Einstieg in Arduino & Co. 9: Schleifen und Datentypen
 
https://youtu.be/yx3kXc89BmE
Das Hilfe-Video: https://youtu.be/hX5yArtfwpU
Das Lösungsvideo: https://youtu.be/VDk6QWanT3A

Diesmal gibt es eine recht anspruchsvolle Lektion und Übungsaufgabe. Du lernst die verschiedenen Schleifentypen kennen. Ausserdem werden weitere Datentypen eingeführt, die wir später gut gebrauchen können. Auch die Übungsaufgabe ist recht anspruchsvoll. Deshalb wird es morgen ein Hilfe-Video geben, das die einige Tipps gibt. Ausserdem kannst du im Forum auf https://community.hobbyelektroniker.ch Fragen stellen, falls etwas nicht klar ist oder nicht so funktioniert, wie du es dir vorstellst.

Du hast keine Idee, wie du das Lauflicht realisieren kannst? Vielleicht bringt dich das Hilfe - Video auf den richtigen Weg.

In den Lösungen zur Übungsaufgabe werde ich sehr genau darauf eingehen, wie man ein solches Projekt entwirft und realisiert. 

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/24

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



