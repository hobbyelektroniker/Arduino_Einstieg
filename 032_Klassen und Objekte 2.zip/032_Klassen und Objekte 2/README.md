# Der einfache Einstieg in Arduino & Co. 32 - Klassen und Objekte 2 
 
https://youtu.be/OakwZpxA6pY

Jetzt verwenden wir Vererbung um eine neue Klasse zur Steuerung einer echten digitalen Led zu erstellen. Als Basisklasse dient die Led - Simulation aus Lektion 31. 

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/78

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



