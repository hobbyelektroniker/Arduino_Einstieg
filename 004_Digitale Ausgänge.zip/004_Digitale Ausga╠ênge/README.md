# Der einfache Einstieg in Arduino & Co. 4: Digitale Ausgänge
 
https://youtu.be/PX4EtHKhN_w

Da dieser Einstieg in den Arduino vermutlich noch einige Zeit dauern wird, habe ich die Serie umbenannt. Neu läuft das unter dem Titel 'Der einfache Einstieg in den Arduino'.

Wir lernen, wie man mit digitalen Ausgängen arbeitet. Ausserdem bringen wir dem Arduino bei über den seriellen Monitor mit uns zu kommunizieren. 

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/24

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



