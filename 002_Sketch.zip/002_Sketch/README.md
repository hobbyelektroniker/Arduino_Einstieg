# Der schnelle Einstieg in Arduino & Co. 2: Ein Arduino - Sketch
 
https://youtu.be/rvvXXMgFYGs

Ein Arduino - Programm (oft auch als Sketch bezeichnet) ist die Grundlage für eigenen Code. Wie muss dieses aufgebaut sein, damit unser Arduino das tut, was wir möchten?

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/24

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



