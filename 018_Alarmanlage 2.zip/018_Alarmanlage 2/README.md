# Der einfache Einstieg in Arduino & Co. 18: Alarmanlage 2 - Sensoren in Modulen
 
https://youtu.be/ATIedo_lldo

LDR, PIR und Ultraschallsensor im selben Sketch kann schon etwas unübersichtlich werden. Deshalb teilen wir das Programm auf. Jeder Sensor bekommt eine eigene Datei. Dadurch bleibt der Sketch schön übersichtlich.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/24

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



