# Der einfache Einstieg in Arduino & Co. 21: Temperatur und Luftfeuchtigkeit
 
https://youtu.be/4u2XgQ-Uu7M

Diesmal wieder etwas ganz Einfaches. Wir messen die Temperatur und die Luftfeuchtigkeit. Wir verwenden die weit verbreiteten Sensoren DHT11 und DHT22. Dank einer Library von Adafruit ist das Ganze ein Kinderspiel.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/24

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



