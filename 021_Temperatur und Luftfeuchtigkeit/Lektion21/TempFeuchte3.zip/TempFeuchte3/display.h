/* 
  Der leichte Einstieg in Arduino & Co.
  Projekt Alarmanlage
  Displayansteuerung
  
  Version 2.00, 08.06.2019
  Der Hobbyelektroniker
  https://community.hobbyelektroniker.ch
  https://www.youtube.com/c/HobbyelektronikerCh
  Der Code kann mit Quellenangabe frei verwendet werden.
*/

class Display {
  public: 
    // Funktionen
    // Alarmstufe  0: ok
    //             1: Licht
    //             2: Bewegung
    //             3: Licht und Bewegung
    //             4: Distanz unterschritten
    void show(int alarmStufe);
    void print(String line1, String line2 = "");
    
    
    void init();   
    int version(); // Version (100 --> Vers. 1.00)

  private:
    void printX(const char a[]);  
};

extern Display display;



    
