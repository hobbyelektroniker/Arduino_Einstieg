# Der einfache Einstieg in Arduino & Co. 34 - Klassen und Objekte 4 
 
https://youtu.be/e6vNHg9WIcU

Diesmal erweitern wir unsere Basisklasse um eine neue Fähigkeit. Diese Fähigkeit steht dann sofort auch allen abgeleiteten Klassen zur Verfügung.
Das ist eine grossartige Eigenschaft der Vererbung, die dir in grösseren Projekten viel Arbeit ersparen kann.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/78

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



