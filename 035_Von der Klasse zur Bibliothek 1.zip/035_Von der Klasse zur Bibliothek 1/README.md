# Der einfache Einstieg in Arduino & Co. 35 - Von der Klasse zur Bibliothek 1
 
https://youtu.be/ltj2j8shPsU

Wie wird eine Klasse zu einer Bibliothek, die von jedem Projekt verwendet werden kann? Eine dreiteilige Serie soll diese Frage beantworten. Im ersten Teil entwickeln eine Klasse für ein langsamen Servo. Dabei wird die Klasse in Header- und Implementationsfile aufgeteilt. In der nächsten Lektion wird dann die Klasse in eine Bibliothek umgewandelt. Im dritten Teil erweitern wir die Bibliothek um weitere Funktionen, ohne bestehenden Code zu beeinträchtigen.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/83

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



