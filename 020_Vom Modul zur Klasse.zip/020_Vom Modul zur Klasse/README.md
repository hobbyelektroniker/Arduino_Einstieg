# Der einfache Einstieg in Arduino & Co. 20: Vom Modul zur Klasse
 
https://youtu.be/VF2k8pr7af0

Sorry, das was heute kommt, wird vielen von euch nicht gefallen. Aber es muss sein!
Vor einiger Zeit habe ich euch ein Konzept mit Modulen vorgestellt, das eine Aufteilung in Programmstücke mit Hilfe von .h und .cpp - Dateien erlaubt. Das hat aber seine Schwächen, so dass ich mich entgegen früherer Versprechen entschlossen habe doch das Konzept der Klassen einzuführen.
Ich versuche das möglichst einfach zu halten. Wir werden damit nur unser Modulkonzept verbessern, versuchen aber noch nicht in die objektorientierte Programmierung einzusteigen.
Es erwartet dich also eine Lektion mit viel Theorie und Programmiererei. Aber versprochen: in der nächsten Lektion geht es wieder mit mehr Praxisbezug weiter. 

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/24

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



