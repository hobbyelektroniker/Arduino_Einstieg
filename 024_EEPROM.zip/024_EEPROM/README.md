# Der einfache Einstieg in Arduino & Co. 24: EEPROM, das Gedächtnis des Arduinos
 
https://youtu.be/BSe0XIECPOE

Wie lassen sich Konfigurationsdaten im Arduino speichern, ohne dass sie beim Ausschalten verloren gehen? Das EEPROM erlaubt es bis zu einem Kilobyte Daten dauerhaft auf dem Arduino zu speichern.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/22

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



