# Der einfache Einstieg in Arduino & Co. 22: Speicheradressen und Zeiger
 
https://youtu.be/cRB2T1ghvVg

Heute wieder einmal eine geballte Portion Programmierung. Wie legt ein Arduino - Sketch seine Variablen im Speicher ab und was sind Zeiger, die auf diese Speicherplätze verweisen? Das sind Fragen, die hier geklärt werden. Zeiger, auch Pointer genannt, sind eine wichtige Grundlage für die nächste Lektion. Dort wird dann die Parameterübergabe an Funktionen näher betrachtet.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/24

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



