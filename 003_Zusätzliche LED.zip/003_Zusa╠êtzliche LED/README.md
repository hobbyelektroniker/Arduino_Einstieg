# Der schnelle Einstieg in Arduino & Co. 3: Eine zusätzliche LED
 
https://youtu.be/pWIj-c8ccU0

Jetzt bauen wir unser Experimentierbrett auf und erweitern den Arduino um eine zusätzliche Leuchtdiode. Du kannst bei dieser Gelegenheit auch gleich mal dein Multimeter einsetzen. Nach einem kleinen Ausflug in die Grundlagen der Elektronik kannst du dein Blink - Programm etwas erweitern. 

Hier noch eine kleine Korrektur:
Die Spannung an der roten Diode ist etwa 1.6V. Die Spannung ist direkt proportional zur Frequenz der emittierten Farbe.
Herzlichen Dank an den Zuschauer, der das bemerkt hat.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/24

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



