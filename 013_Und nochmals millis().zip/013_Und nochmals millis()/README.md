# Der einfache Einstieg in Arduino & Co. 13: Spielereien mit millis()
 
https://youtu.be/RtTtCMj_LDE

Weiter geht es mit den millis(). Wir spielen etwas mit dem Timing unserer 5 Led's. Die Lektion ist nicht ganz einfach, man kann aber viel dabei lernen.
Das ist die Letzte der 'schwierigen' Lektionen. Ab nächster Woche geht es entspannter und praxisorientierter mit Sensoren und Aktoren weiter. 

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/24

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



