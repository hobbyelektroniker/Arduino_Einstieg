/* 
  Der leichte Einstieg in Arduino & Co.
  Projekt Alarmanlage
  Licht - Sensor (LDR)
  
  Version 1.00, 09.05.2019
  Der Hobbyelektroniker
  https://community.hobbyelektroniker.ch
  https://www.youtube.com/c/HobbyelektronikerCh
  Der Code kann mit Quellenangabe frei verwendet werden.
*/

// Funktionen
int licht_staerke();

void licht_init();
int licht_version();
