/* 
  Der leichte Einstieg in Arduino & Co.
  Projekt Alarmanlage
  PIR - Sensor
  
  Version 1.00, 14.05.2019
  Der Hobbyelektroniker
  https://community.hobbyelektroniker.ch
  https://www.youtube.com/c/HobbyelektronikerCh
  Der Code kann mit Quellenangabe frei verwendet werden.
*/


// Funktionen
boolean pir_bewegung();


void pir_init();
int pir_version();
