
#include "Blink.h"

void init13() {
  initLed(13);
}

void blink13(int zeit) {
  blinkLed(13,zeit);
}
