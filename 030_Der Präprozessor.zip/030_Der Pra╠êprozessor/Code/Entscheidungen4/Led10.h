
#include "Blink.h"

void init10() {
  initLed(10);
}

void blink10(int zeit) {
  blinkLed(10,zeit);
}
