# Der einfache Einstieg in Arduino & Co. 30 - #define und andere Präprozessorbefehle
 
https://youtu.be/wzl5dLsxH2k

Die Programmiersprache C bietet auch leistungsfähige Makro-Befehle an. Diese werden von einem Präprozessor vor dem eigentlichen Kompilierungsvorgang abgearbeitet. Wir werfen heute einen Blick auf #define, #include, #ifdef und ähnliche Befehle.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/73

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



