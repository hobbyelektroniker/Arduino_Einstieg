# Der einfache Einstieg in Arduino & Co. 23: Funktionen
 
https://youtu.be/P2ZLfgNMySQ

Jetzt geht es weiter mit Funktionen. Bei der Parameterübergabe gibt es verschiedene Möglichkeiten, die man kennen sollte. Deine Kenntnisse über Pointer werden dir hier weiterhelfen.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/24

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



