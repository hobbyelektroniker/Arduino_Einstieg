# Der einfache Einstieg in Arduino & Co. 12: Das richtige Timing
 
https://youtu.be/zNzhughaHUE

Mit delay() wirst du mit dem Timing in deinem Programm rasch an Grenzen stossen. Du lernst in dieser Lektion den Umgang mit millis() kennen. Ausserdem benutzen wir statische Variablen und ich zeige dir eine universelle Blink-Funktion, die ohne delay() auskommt.
Diesmal wird es kein Lösungsvideo dazu geben. Da das Thema recht komplex ist, wird es eine weitere Lektion zur Vertiefung des Stoffes geben.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/24

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



