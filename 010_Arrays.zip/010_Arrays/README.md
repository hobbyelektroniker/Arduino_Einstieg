# Der einfache Einstieg in Arduino & Co. 10: Arrays
 
https://youtu.be/qhIZlLmKLW4
Das Lösungsvideo: https://youtu.be/3U-LgmakvH0

Arrays sind ein wichtiger Bestandteil jeder Programmiersprache. Sie werden deine Möglichkeiten stark erweitern. Diese Lektion ist recht umfangreich. Plane also etwas Zeit ein, damit du die Beispiele auch nachvollziehen kannst. Eine Diskussion mit anderen Kursteilnehmern im Forum auf https://community.hobbyelektroniker.ch dürfte auch ganz hilfreich sein.

Die Übungsaufgabe ist diesmal nicht besonders schwierig. Die dabei aufgebaute Hardware wird aber in späteren Lektionen nochmals verwendet werden. 

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/24

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



