/* 
  Der leichte Einstieg in Arduino & Co.
  Projekt Alarmanlage
  Globale Definitionen
  
  Version 1.00, 09.05.2019
  Der Hobbyelektroniker
  https://community.hobbyelektroniker.ch
  https://www.youtube.com/c/HobbyelektronikerCh
  Der Code kann mit Quellenangabe frei verwendet werden.
*/

const int pirPin = 6;
const int lichtPin = A2;
