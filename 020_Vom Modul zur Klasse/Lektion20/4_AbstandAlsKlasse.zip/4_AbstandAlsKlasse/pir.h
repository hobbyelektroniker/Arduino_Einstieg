/* 
  Der leichte Einstieg in Arduino & Co.
  Projekt Alarmanlage
  PIR - Sensor
  
  Version Version 2.00, 09.05.2019
  Der Hobbyelektroniker
  https://community.hobbyelektroniker.ch
  https://www.youtube.com/c/HobbyelektronikerCh
  Der Code kann mit Quellenangabe frei verwendet werden.
*/

class Pir {
  public:
    // Funktionen
    boolean bewegung();

    void init(int pirPin);
    int version();

  private:
    int pin;
};
