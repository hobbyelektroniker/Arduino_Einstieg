/* 
  Der leichte Einstieg in Arduino & Co.
  Projekt Alarmanlage
  Leuchtdioden
  
  Version 2.00, 08.06.2019
  Der Hobbyelektroniker
  https://community.hobbyelektroniker.ch
  https://www.youtube.com/c/HobbyelektronikerCh
  Der Code kann mit Quellenangabe frei verwendet werden.
*/

class Leds {
  public: 
    // Funktionen
    // Alarmstufe  0: ok
    //             1: Licht
    //             2: Bewegung
    //             3: Licht und Bewegung
    //             4: Distanz unterschritten
    void show(int alarmStufe);
    
    void init();   // Led's initialisieren
    int version(); // Version (100 --> Vers. 1.00)

  private:
    // Aktuelle Zustände der Led's
    int ledZustand[3]; 
    void ledBlink();
    void ledAnzeige();
     
};

extern Leds leds;
