/* 
  Der leichte Einstieg in Arduino & Co.
  Projekt Alarmanlage
  Ultraschallsensor
  
  Version 2.00, 09.05.2019
  Der Hobbyelektroniker
  https://community.hobbyelektroniker.ch
  https://www.youtube.com/c/HobbyelektronikerCh
  Der Code kann mit Quellenangabe frei verwendet werden.
*/

class Abstand {
  public:  
    // Funktionen
    int cm();
    
    void init();   // Ultraschallsensor initialisieren
    int version(); // Version (100 --> Vers. 1.00)
};

extern Abstand abstand;
