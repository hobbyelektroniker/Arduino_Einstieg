/* 
  Der leichte Einstieg in Arduino & Co.
  Projekt Alarmanlage
  Licht - Sensor (LDR)
  
  Version 2.00, 09.05.2019
  Der Hobbyelektroniker
  https://community.hobbyelektroniker.ch
  https://www.youtube.com/c/HobbyelektronikerCh
  Der Code kann mit Quellenangabe frei verwendet werden.
*/
 
#define VERS 200

#include <arduino.h>
#include "globals.h"
#include "licht.h"

int Licht::staerke() {
  return analogRead(pin);
}

void Licht::init(int lichtPin) {
  pin = lichtPin;
}

int Licht::version() {
  return VERS;
}
