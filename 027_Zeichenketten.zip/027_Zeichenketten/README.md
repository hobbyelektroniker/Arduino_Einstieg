# Der einfache Einstieg in Arduino & Co. 27 - C-Strings 
 
https://youtu.be/QspKi32jOPE

Strings (Zeichenketten) sind ein wichtiger Bestandteil in jeder Programmiersprache. In C werden diese ähnlich wie Arrays behandelt, haben aber wichtige Eigenheiten. Auf die String - Klasse gehen wir in dieser Lektion noch nicht ein.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/69

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



