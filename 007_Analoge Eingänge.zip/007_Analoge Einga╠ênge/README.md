# Der einfache Einstieg in Arduino & Co. 7: Analoge Eingänge
 
https://youtu.be/Rxr71G7TNeU
Das Lösungsvideo: https://youtu.be/erkAPpZ2NQw

Ein Voltmeter, ein automatisches Licht und eine Alarmanlage. Das sind Beispiele, die wir im Zusammenhang mit analogen Eingängen am Arduino anschauen. Da die Lösung der Aufgaben schon etwas komplizierter ist, gibt es ein eigenes Lösungsvideo dazu. Das Lösungsvideo wird gleichzeitig mit diesem Video freigeschaltet.


Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/24

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



