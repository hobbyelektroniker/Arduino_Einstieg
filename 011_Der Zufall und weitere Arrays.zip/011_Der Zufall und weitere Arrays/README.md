# Der einfache Einstieg in Arduino & Co. 11: Der Zufall und weitere Arrays
 
https://youtu.be/b02KwXSZAI8
Das Lösungsvideo: https://youtu.be/S-1Krx9_FTM

Mit dem Würfel aus der letzten Lektion wollen wir jetzt auch würfeln. Dazu braucht es ein Zufallselement. Damit die Ergebnisse aber auch wirklich zufällig sind, müssen einige Dinge beachtet werden. Bei dieser Gelegenheit lernst du auch noch den switch .. case Befehl kennen.

In der Übungsaufgabe überprüfen wir, wie fair unser Würfel arbeitet. Diese kleine Aufgabe ist wieder einmal eine gute Übung zum Thema Array. Kommst du auf ähnliche Ergebnisse?

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/24

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



