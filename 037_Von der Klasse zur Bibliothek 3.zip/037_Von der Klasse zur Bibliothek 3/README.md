# Der einfache Einstieg in Arduino & Co. 37 - Von der Klasse zur Bibliothek 3
 
https://youtu.be/QuVrxjdYf5E

Damit andere Programmierer unsere ZIP-Datei einbinden können, müssen wir sie ihnen zur Verfügung stellen. Dazu eignen sich diverse Dienste im Internet. Wir verwenden hier Git, GitHub und GitHub Desktop.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/86

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



