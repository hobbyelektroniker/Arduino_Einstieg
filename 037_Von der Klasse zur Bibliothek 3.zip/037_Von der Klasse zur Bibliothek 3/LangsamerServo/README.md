# LangsamerServo
 Arduino Library für einen langsamen Servo
 Diese wird auf GitHub veröffentlicht.
 
