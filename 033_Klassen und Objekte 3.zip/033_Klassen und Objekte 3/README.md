# Der einfache Einstieg in Arduino & Co. 33 - Klassen und Objekte 3 
 
https://youtu.be/WYPMm3NOG1k

Jetzt erzeugen wir noch eine Klasse zur Ansteuerung einer analogen Led. Bei diese Gelegenheit sprechen wird auch noch über Klassen- und Instanzvariablen. Wir bauen einen Instanzzähler und lernen dabei auch den Destruktor kennen.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/78

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



