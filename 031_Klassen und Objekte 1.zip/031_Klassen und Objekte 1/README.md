# Der einfache Einstieg in Arduino & Co. 31 - Klassen und Objekte 1 
 
https://youtu.be/2c8z-O5Yskc

Das ist der Start zu einer mehrteiligen Einführung in die objektorientierte Programmierung. Klassen und Objekte sind Bestandteil beinahe jeder Arduino - Bibliothek. Eigene Klassen zu erstellen eröffnet uns neue Möglichkeiten. In dieser Lektion beginnen wir sehr einfach. Es geht nur darum, eine einfache Klasse zu erstellen und zu verwenden. 

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/78

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



