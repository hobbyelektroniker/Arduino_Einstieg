# Der einfache Einstieg in Arduino & Co. 6: Programmierung - ein Einstieg
 
https://youtu.be/O8js5Tw8xlA

Es ist Zeit für eine kleine Einführung in die Programmierung. Welche Programmiersprache verwendet der Arduino? Was sind Konstanten, Variablen, Funktionen? Wie kann der Arduino rechnen? Wie geht das mit diesen if und else? Etwas fortgeschritten ist die Frage: Kann ich einer Funktion eine Funktion übergeben?
Alle diese Fragen werden beantwortet.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/24

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



