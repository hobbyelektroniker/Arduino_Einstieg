# Der schnelle Einstieg in Arduino & Co. : Der Kurs beginnt
 
https://youtu.be/FZAqXy-G5ww

Das ist der Start eines Arduino Einsteigerkurses für absolute Einsteiger.  Das ist erst der Anfang, der Kurs wird nach und nach erweitert.

Achtung Arduino - Profis! Diese Video ist nichts für euch!
Wenn du aber in den Arduino einsteigen möchtest und nicht so recht weisst, wo du beginnen sollst, dann kann dir dieses Video weiterhelfen.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/24

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



