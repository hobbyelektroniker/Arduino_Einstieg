# Der einfache Einstieg in Arduino & Co. 8: Analoge Ausgänge
 
https://youtu.be/zGa-8W14mvM
Das Lösungsvideo: https://youtu.be/3kxeiAAmtv8

Diesmal geben wir analoge Werte aus. Der Arduino stellt dafür den Befehl analogWrite() zur Verfügung. Aber hat der Arduino überhaupt richtige analoge Ausgänge?

Ich zeige dir im Lösungsvideo zwei verschiedene Lösungsvarianten zur Übungsaufgabe.
Vielleicht hast du ja eine noch bessere Lösung gefunden?

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/24

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



