# Der einfache Einstieg in Arduino & Co. 5: Digitale Eingänge
 
https://youtu.be/6ue1MGzFUkc

Jetzt beschäftigen wir uns mit digitalen Eingängen und wieso PULLUP ein wichtiger Begriff ist.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/24

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



