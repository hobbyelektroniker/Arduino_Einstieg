# Der einfache Einstieg in Arduino & Co. 28 - Die String-Klasse 
 
https://youtu.be/KWvg-8bD5EU

Die Klasse String vereinfacht den Umgang mit Zeichenketten enorm. Doch es gibt aber auch Nachteile.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/71

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



