# Der einfache Einstieg in Arduino & Co. 25: Der Highspeed - Arduino
 
https://youtu.be/HQYtuA0vdf4

Lässt sich der Arduino als Rechteckgenerator verwenden? Sicher! Aber funktioniert das auch bei höheren Frequenzen?

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/60

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



