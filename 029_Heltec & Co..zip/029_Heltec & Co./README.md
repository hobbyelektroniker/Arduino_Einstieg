# Der einfache Einstieg in Arduino & Co. 29 - ... und wo bleibt das & Co.? 
 
https://youtu.be/S6ejwOwxa-k

Diesmal gibt es keine neuen Lerninhalte. Ich zeige aber an einem Beispiel, wie man ein nicht-Arduino Board in die Arduino IDE einbindet und ein Beispielprogramm ausführt.

Diskussionen, Fragen und Antworten auf 
https://community.hobbyelektroniker.ch/wbb/index.php?board/73

Falls du mich unterstützen möchtest:

Paypal: https://www.paypal.me/hobbyelektroniker<br>
Patreon: https://www.patreon.com/hobbyelektroniker

Für Unterstützer auf Patreon steht das Video werbefrei zur Verfügung.



